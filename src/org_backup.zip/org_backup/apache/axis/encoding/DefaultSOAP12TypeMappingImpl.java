package org.apache.axis.encoding;

/**
 * @author James M Snell <jasnell@us.ibm.com>
 * @deprecated Please use DefaultSOAPEncodingTypeMappingImpl.java
 * @see org.apache.axis.encoding.DefaultSOAPEncodingTypeMappingImpl 
 */
public class DefaultSOAP12TypeMappingImpl
  extends DefaultSOAPEncodingTypeMappingImpl {
  
  public DefaultSOAP12TypeMappingImpl() {
  }

}
